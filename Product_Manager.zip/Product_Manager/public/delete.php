<?php

session_start();

require_once "../config/db.php";


// DELETE harus menggunakan POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    header("Location: index.php");
    exit;
}


// Cek CSRF
$csrf_token = $_POST["csrf_token"] ?? "";

if (
    empty($_SESSION["csrf_token"]) ||
    !hash_equals($_SESSION["csrf_token"], $csrf_token)
) {

    die("Token CSRF tidak valid.");
}


// Ambil ID
$id = (int) ($_POST["id"] ?? 0);


if ($id <= 0) {

    header("Location: index.php");
    exit;
}


// Hapus produk
$stmt = $pdo->prepare(
    "DELETE FROM products WHERE id = :id"
);

$stmt->execute([
    "id" => $id
]);


// Kembali ke halaman utama
header("Location: index.php?status=deleted");
exit;