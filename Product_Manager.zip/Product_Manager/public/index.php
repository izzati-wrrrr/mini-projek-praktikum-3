<?php

session_start();

require_once "../config/db.php";

// CSRF Token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}


// =========================
// SEARCH
// =========================

$search = trim($_GET["search"] ?? "");

if ($search !== "") {

    $stmt = $pdo->prepare(
        "SELECT * FROM products
         WHERE name LIKE :search
         ORDER BY id DESC"
    );

    $stmt->execute([
        "search" => "%" . $search . "%"
    ]);

} else {

    $stmt = $pdo->prepare(
        "SELECT * FROM products
         ORDER BY id DESC"
    );

    $stmt->execute();
}

$products = $stmt->fetchAll();


// =========================
// STATISTICS
// =========================

$totalProducts = count($products);

$totalStock = 0;

$categories = [];

foreach ($products as $product) {

    $totalStock += $product["stock"];

    $categories[$product["category"]] = true;
}

$totalCategories = count($categories);

$status = $_GET["status"] ?? "";

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Sweet Crumbs Bakery</title>

    <link rel="stylesheet" href="assets/style.css">

</head>


<body>

<div class="container">


    <!-- =========================
         HERO
    ========================== -->

    <header class="hero">

        <div class="hero-content">

            <span class="brand-small">
                SWEET CRUMBS BAKERY
            </span>

            <h1>
                Freshly Baked,
                <br>
                Simply Managed.
            </h1>

            <p>
                Kelola produk bakery dengan mudah,
                rapi, dan praktis.
            </p>

            <a href="create.php" class="btn-main">
                + Tambah Produk
            </a>

        </div>

        <div class="hero-decoration">
            🧁
        </div>

    </header>


    <!-- =========================
         STATISTICS
    ========================== -->

    <section class="stats">

        <div class="stat-card">

            <div class="stat-icon">
                🍰
            </div>

            <div>
                <span class="stat-number">
                    <?= $totalProducts ?>
                </span>

                <span class="stat-label">
                    Produk
                </span>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                📦
            </div>

            <div>
                <span class="stat-number">
                    <?= $totalStock ?>
                </span>

                <span class="stat-label">
                    Total Stok
                </span>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">
                🏷️
            </div>

            <div>
                <span class="stat-number">
                    <?= $totalCategories ?>
                </span>

                <span class="stat-label">
                    Kategori
                </span>
            </div>

        </div>

    </section>


    <!-- =========================
         NOTIFICATION
    ========================== -->

    <?php if ($status === "created"): ?>

        <div class="success">
            ✓ Produk berhasil ditambahkan!
        </div>

    <?php elseif ($status === "updated"): ?>

        <div class="success">
            ✓ Produk berhasil diperbarui!
        </div>

    <?php elseif ($status === "deleted"): ?>

        <div class="success">
            ✓ Produk berhasil dihapus!
        </div>

    <?php endif; ?>


    <!-- =========================
         PRODUCT HEADER
    ========================== -->

    <div class="section-header">

        <div>

            <span class="section-small">
                OUR COLLECTION
            </span>

            <h2>
                Produk Kami
            </h2>

        </div>

        <span class="product-count">
            <?= $totalProducts ?> produk
        </span>

    </div>


    <!-- =========================
         SEARCH
    ========================== -->

    <form
        action="index.php"
        method="GET"
        class="search-form"
    >

        <div class="search-box">

            <span>
                🔍
            </span>

            <input
                type="text"
                name="search"
                placeholder="Cari nama produk..."
                value="<?= htmlspecialchars($search) ?>"
            >

        </div>


        <button type="submit" class="btn-search">
            Cari
        </button>


        <?php if ($search !== ""): ?>

            <a
                href="index.php"
                class="btn-reset"
            >
                Reset
            </a>

        <?php endif; ?>

    </form>


    <!-- =========================
         PRODUCTS
    ========================== -->

    <div class="product-grid">

        <?php if (empty($products)): ?>

            <div class="empty">

                <div class="empty-icon">
                    🧁
                </div>

                <h2>
                    Produk tidak ditemukan
                </h2>

                <p>
                    Coba gunakan kata pencarian lain.
                </p>

            </div>

        <?php else: ?>


            <?php foreach ($products as $product): ?>

                <div class="product-card">

                    <div class="product-top">

                       

                        <span class="category">
                            <?= htmlspecialchars($product["category"]) ?>
                        </span>

                    </div>


                    <h3>
                        <?= htmlspecialchars($product["name"]) ?>
                    </h3>


                    <div class="price">
                        Rp <?= number_format(
                            $product["price"],
                            0,
                            ',',
                            '.'
                        ) ?>
                    </div>


                    <div class="stock">

                        <span>
                            Stok tersedia
                        </span>

                        <strong>
                            <?= $product["stock"] ?>
                        </strong>

                    </div>


                    <div class="actions">

                        <a
                            href="edit.php?id=<?= $product["id"] ?>"
                            class="btn-edit"
                        >
                            Edit
                        </a>


                        <form
                            action="delete.php"
                            method="POST"
                            onsubmit="return confirm('Yakin ingin menghapus produk ini?');"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= htmlspecialchars($_SESSION["csrf_token"]) ?>"
                            >

                            <input
                                type="hidden"
                                name="id"
                                value="<?= $product["id"] ?>"
                            >

                            <button
                                type="submit"
                                class="btn-delete"
                            >
                                Hapus
                            </button>

                        </form>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>


    <!-- =========================
         FOOTER
    ========================== -->

    <footer>

        <strong>
            Sweet Crumbs Bakery
        </strong>

        <span>
            Product Manager
        </span>

    </footer>


</div>

</body>

</html>