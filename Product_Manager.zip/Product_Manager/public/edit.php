<?php

session_start();

require_once "../config/db.php";

$id = (int) ($_GET["id"] ?? 0);


// Cek ID
if ($id <= 0) {
    die("ID produk tidak valid.");
}


// Ambil produk berdasarkan ID
$stmt = $pdo->prepare(
    "SELECT * FROM products WHERE id = :id"
);

$stmt->execute([
    "id" => $id
]);

$product = $stmt->fetch();


if (!$product) {
    die("Produk tidak ditemukan.");
}


$errors = [];


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $category = trim($_POST["category"] ?? "");
    $price = (float) ($_POST["price"] ?? 0);
    $stock = (int) ($_POST["stock"] ?? 0);


    // Validasi nama
    if (strlen($name) < 3) {
        $errors[] = "Nama produk minimal 3 karakter.";
    }


    // Validasi kategori
    if ($category === "") {
        $errors[] = "Kategori wajib diisi.";
    }


    // Validasi harga
    if ($price <= 0) {
        $errors[] = "Harga harus lebih dari 0.";
    }


    // Validasi stok
    if ($stock < 0) {
        $errors[] = "Stok tidak boleh kurang dari 0.";
    }


    // Cek nama duplikat
    $stmt = $pdo->prepare(
        "SELECT COUNT(*)
         FROM products
         WHERE name = :name
         AND id != :id"
    );

    $stmt->execute([
        "name" => $name,
        "id" => $id
    ]);


    if ($stmt->fetchColumn() > 0) {
        $errors[] = "Nama produk sudah digunakan.";
    }


    // Update jika tidak ada error
    if (empty($errors)) {

        $stmt = $pdo->prepare(
            "UPDATE products
             SET
                name = :name,
                category = :category,
                price = :price,
                stock = :stock
             WHERE id = :id"
        );


        $stmt->execute([
            "name" => $name,
            "category" => $category,
            "price" => $price,
            "stock" => $stock,
            "id" => $id
        ]);


        header("Location: index.php?status=updated");
        exit;
    }


    // Tampilkan kembali data yang diinput
    $product["name"] = $name;
    $product["category"] = $category;
    $product["price"] = $price;
    $product["stock"] = $stock;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Produk</title>

    <link rel="stylesheet" href="assets/style.css">

</head>

<body>

<div class="container">

    <div class="form-card">

        <h1>Edit Produk</h1>


        <?php if (!empty($errors)): ?>

            <div class="error">

                <ul>

                    <?php foreach ($errors as $error): ?>

                        <li>
                            <?= htmlspecialchars($error) ?>
                        </li>

                    <?php endforeach; ?>

                </ul>

            </div>

        <?php endif; ?>


        <form method="POST">

            <label for="name">
                Nama Produk
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= htmlspecialchars($product["name"]) ?>"
                minlength="3"
                required
            >


            <label for="category">
                Kategori
            </label>

            <select id="category" name="category" required>

                <option value="">-- Pilih Kategori --</option>

                <option value="Cake" <?= $product["category"] === "Cake" ? "selected" : "" ?>>
                    Cake
                </option>

                <option value="Pastry" <?= $product["category"] === "Pastry" ? "selected" : "" ?>>
                    Pastry
                </option>

                <option value="Donat" <?= $product["category"] === "Donat" ? "selected" : "" ?>>
                    Donat
                </option>

                <option value="Cookies" <?= $product["category"] === "Cookies" ? "selected" : "" ?>>
                    Cookies
                </option>

                <option value="Roti" <?= $product["category"] === "Roti" ? "selected" : "" ?>>
                    Roti
                </option>

            </select>


            <label for="price">
                Harga
            </label>

            <input
                type="number"
                id="price"
                name="price"
                value="<?= $product["price"] ?>"
                min="1"
                required
            >


            <label for="stock">
                Stok
            </label>

            <input
                type="number"
                id="stock"
                name="stock"
                value="<?= $product["stock"] ?>"
                min="0"
                required
            >


            <button type="submit" class="btn">
                Simpan Perubahan
            </button>

        </form>


        <br>

        <a href="index.php">
            ← Kembali ke Produk
        </a>

    </div>

</div>

</body>

</html>