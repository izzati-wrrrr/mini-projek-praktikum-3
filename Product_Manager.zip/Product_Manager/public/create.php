<?php

session_start();

require_once "../config/db.php";

$errors = [];

$name = "";
$category = "";
$price = "";
$stock = "";


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Ambil data dari form
    $name = trim($_POST["name"] ?? "");
    $category = trim($_POST["category"] ?? "");
    $price = (float) ($_POST["price"] ?? 0);
    $stock = (int) ($_POST["stock"] ?? 0);


    // Validasi nama
    if (strlen($name) < 3) {
        $errors[] = "Nama produk minimal 3 karakter.";
    }


    // Validasi kategori
    if ($category === "") {
        $errors[] = "Kategori wajib diisi.";
    }


    // Validasi harga
    if ($price <= 0) {
        $errors[] = "Harga harus lebih dari 0.";
    }


    // Validasi stok
    if ($stock < 0) {
        $errors[] = "Stok tidak boleh kurang dari 0.";
    }


    // Cek nama produk
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM products WHERE name = :name"
    );

    $stmt->execute([
        "name" => $name
    ]);


    if ($stmt->fetchColumn() > 0) {
        $errors[] = "Nama produk sudah digunakan.";
    }


    // Kalau tidak ada error
    if (empty($errors)) {

        $stmt = $pdo->prepare(
            "INSERT INTO products
            (name, category, price, stock)
            VALUES
            (:name, :category, :price, :stock)"
        );


        $stmt->execute([
            "name" => $name,
            "category" => $category,
            "price" => $price,
            "stock" => $stock
        ]);


        // Redirect setelah berhasil
        header("Location: index.php?status=created");
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Tambah Produk</title>

    <link rel="stylesheet" href="assets/style.css">

</head>

<body>

<div class="container">

    <div class="form-card">

        <h1>Tambah Produk</h1>


        <?php if (!empty($errors)): ?>

            <div class="error">

                <ul>

                    <?php foreach ($errors as $error): ?>

                        <li>
                            <?= htmlspecialchars($error) ?>
                        </li>

                    <?php endforeach; ?>

                </ul>

            </div>

        <?php endif; ?>


        <form method="POST">

            <label for="name">
                Nama Produk
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= htmlspecialchars($name) ?>"
                minlength="3"
                required
            >


            <label for="category">
                Kategori
            </label>

            <select id="category" name="category" required>

                <option value="">-- Pilih Kategori --</option>

                <option value="Cake" <?= $category === "Cake" ? "selected" : "" ?>>
                    Cake
                </option>

                <option value="Pastry" <?= $category === "Pastry" ? "selected" : "" ?>>
                    Pastry
                </option>

                <option value="Donat" <?= $category === "Donat" ? "selected" : "" ?>>
                    Donat
                </option>

                <option value="Cookies" <?= $category === "Cookies" ? "selected" : "" ?>>
                    Cookies
                </option>

                <option value="Roti" <?= $category === "Roti" ? "selected" : "" ?>>
                    Roti
                </option>

            </select>


            <label for="price">
                Harga
            </label>

            <input
                type="number"
                id="price"
                name="price"
                value="<?= htmlspecialchars($price) ?>"
                min="1"
                required
            >


            <label for="stock">
                Stok
            </label>

            <input
                type="number"
                id="stock"
                name="stock"
                value="<?= htmlspecialchars($stock) ?>"
                min="0"
                required
            >


            <button type="submit" class="btn">
                Simpan Produk
            </button>

        </form>


        <br>

        <a href="index.php">
            ← Kembali ke Produk
        </a>

    </div>

</div>

</body>

</html>